from setuptools import setup, find_packages

setup(
    name='hello',
    version='0.1',
    packages=find_packages(),
    description='A simple hello world package',
    url='https://github.com/kp9z/hello',
    author='Kenny',
    author_email='hi@anhtrinh.com',
    license='MIT',
)
