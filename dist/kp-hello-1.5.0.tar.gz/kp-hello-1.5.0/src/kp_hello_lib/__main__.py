from .utils import say_hi

def main():
    print("this is the main function")

if __name__ == "__main__":
    main()